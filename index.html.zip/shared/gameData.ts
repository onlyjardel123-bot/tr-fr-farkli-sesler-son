export type Pair = {
  id: string;
  letter: string;
  word: string;
  french: string;
  emoji: string;
  note?: string;
};

export type GameCard =
  | { id: string; pairId: string; type: "letter"; letter: string }
  | { id: string; pairId: string; type: "word"; letter: string; word: string; french: string; emoji: string; note?: string };

export const TARGET_LETTERS = ["b", "c", "ç", "e", "g", "ğ", "h", "ı", "ö", "s", "ş", "u", "ü", "y"] as const;

export const PAIRS: Pair[] = [
  { id: "b-balik", letter: "b", word: "balık", french: "poisson", emoji: "🐟" },
  { id: "c-ceviz", letter: "c", word: "ceviz", french: "noix", emoji: "🌰" },
  { id: "ç-cilek", letter: "ç", word: "çilek", french: "fraise", emoji: "🍓" },
  { id: "e-elma", letter: "e", word: "elma", french: "pomme", emoji: "🍎" },
  { id: "g-gunes", letter: "g", word: "güneş", french: "soleil", emoji: "☀️" },
  { id: "ğ-dag", letter: "ğ", word: "dağ", french: "montagne", emoji: "⛰️", note: "Ğ kelimenin başında olmaz." },
  { id: "h-horoz", letter: "h", word: "horoz", french: "coq", emoji: "🐓" },
  { id: "ı-isi", letter: "ı", word: "ısı", french: "chaleur", emoji: "🔥" },
  { id: "ö-ordek", letter: "ö", word: "ördek", french: "canard", emoji: "🦆" },
  { id: "s-sabun", letter: "s", word: "sabun", french: "savon", emoji: "🧼" },
  { id: "ş-sapka", letter: "ş", word: "şapka", french: "chapeau", emoji: "🧢" },
  { id: "u-ucak", letter: "u", word: "uçak", french: "avion", emoji: "✈️" },
  { id: "ü-uzum", letter: "ü", word: "üzüm", french: "raisin", emoji: "🍇" },
  { id: "y-yildiz", letter: "y", word: "yıldız", french: "étoile", emoji: "⭐" },
];

export const FINAL_PASSWORD = "MANTI";

export function buildDeck(): GameCard[] {
  const cards = PAIRS.flatMap(pair => [
    { id: `${pair.id}-letter`, pairId: pair.id, type: "letter" as const, letter: pair.letter },
    { id: `${pair.id}-word`, pairId: pair.id, type: "word" as const, letter: pair.letter, word: pair.word, french: pair.french, emoji: pair.emoji, note: pair.note },
  ]);
  return [...cards].sort(() => Math.random() - 0.5);
}

export function normalizeNickname(value: string): string {
  return value.trim().replace(/\s+/g, " ").slice(0, 80);
}

export function localDateKey(value: Date | number): string {
  const date = value instanceof Date ? value : new Date(value);
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}
