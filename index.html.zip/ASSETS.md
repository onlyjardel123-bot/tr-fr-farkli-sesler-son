# Assets

**Art direction:** Neşeli, yumuşak ve yüksek kontrastlı çocuk eğitim oyunu. Sıcak krem kâğıt yüzey, gökyüzü mavisi, güneş sarısı, mercan ve nane yeşili vurgu renkleri. Kalın koyu konturlar, iri yuvarlatılmış kartlar, rahat boşluk ve 7-8 yaş için okunaklı tipografi. Görsel dil masalsı ama sakin; kartların üzerindeki kelimeler ve harfler her zaman UI tarafından net yazıyla gösterilir.

## Generated art

| Name | Description | Size | Source / URL | Use |
|------|-------------|------|--------------|-----|
| reference | Finished-game visual target showing the card grid, header and palette | 2560x1440 | `/home/ubuntu/webdev-static-assets/turkce-harf-hafiza-reference.png` | Art direction and QA reference |
| paper | Warm cream paper/confetti background with quiet center | 2560x1440 | `/manus-storage/turkce-harf-hafiza-paper_24fdd55e.png` | Full-page game background |
| turtle | Friendly turtle mascot holding a Turkish letter flashcard | 1:1 | `/manus-storage/turkce-harf-hafiza-turtle_4c4d42c3.png` | Start and completion cards |

## Runtime illustration strategy

The card faces use large, readable emoji/pictograms for the simple objects (fruit, animals and everyday things) so children can recognize them at a glance and the UI stays fast and accessible. The generated paper background and turtle mascot provide the cohesive art direction required by the game pipeline without shrinking detailed illustrations into tiny cards. The deck has 13 requested letters, 26 word pairs and 52 total cards.

## Asset assignments

- Start screen: `turtle` mascot, displayed at about 96px on desktop and 72px on mobile.
- Main shell: `paper` as a cover background with a soft white overlay for card readability.
- Card face: emoji from `shared/gameData.ts`, displayed at 30-40px; Turkish word in bold and French translation below in smaller text.
