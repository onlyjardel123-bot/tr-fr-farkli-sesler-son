import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/** Core user table backing the built-in Manus auth flow. */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const gameCompletions = mysqlTable("game_completions", {
  id: int("id").autoincrement().primaryKey(),
  nickname: varchar("nickname", { length: 80 }).notNull(),
  moves: int("moves").notNull(),
  mistakes: int("mistakes").notNull(),
  durationSeconds: int("durationSeconds").notNull(),
  password: varchar("password", { length: 32 }).notNull(),
  completedAt: timestamp("completedAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type GameCompletion = typeof gameCompletions.$inferSelect;
export type InsertGameCompletion = typeof gameCompletions.$inferInsert;
