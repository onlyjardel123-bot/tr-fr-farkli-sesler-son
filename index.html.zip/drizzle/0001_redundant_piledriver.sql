CREATE TABLE `game_completions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`nickname` varchar(24) NOT NULL,
	`moves` int NOT NULL,
	`mistakes` int NOT NULL,
	`durationSeconds` int NOT NULL,
	`password` varchar(32) NOT NULL,
	`completedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `game_completions_id` PRIMARY KEY(`id`)
);
