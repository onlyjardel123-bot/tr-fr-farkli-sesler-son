# Structure: Türkçe Harf Hafıza Oyunu

## UI shell

- `client/src/App.tsx` — public game route `/` and admin results route `/sonuclar`.
- `client/src/components/GameCanvas.tsx` — Babylon.js canvas lifecycle and decorative floating tiles; React game UI is layered above it.
- `client/src/pages/Home.tsx` — nickname onboarding, instructions, game board, completion state and local speech controls.
- `client/src/pages/Results.tsx` — owner/admin-only completion list.
- `client/src/index.css` — warm paper palette, card flip motion, responsive layout and reduced-motion rules.

## Gameplay data

- `shared/gameData.ts` — the single source of truth for the 14 Turkish target letters, 14 word pairs, French translations, emoji illustrations and card construction.
- `client/src/game/` — reserved for framework-independent gameplay classes if the game grows; this small implementation keeps deterministic state in the page and data module.

## Backend

- `drizzle/schema.ts` — `gameCompletions` table alongside the built-in `users` table.
- `server/db.ts` — insert/list helpers for completion records.
- `server/routers.ts` — public `game.saveCompletion` and admin-only `game.listCompletions` tRPC procedures.
- `server/game.data.test.ts` — deterministic unit coverage for the card set and Turkish letter inventory.

## Runtime flow

1. Child enters a nickname locally and starts; the first click unlocks browser speech.
2. `shared/gameData.ts` creates 28 shuffled cards: 14 letter cards + 14 image/word cards, where each of the 14 pairs shares a `pairId`.
3. Clicking a card reveals it and speaks its Turkish letter or word. A pair stays revealed when the `pairId` matches.
4. On completion, a public mutation stores the nickname, statistics and UTC completion timestamp. The result view shows the Bursa password.
5. The owner can log in through Manus OAuth and open `/sonuclar` to see completed nicknames and times.
