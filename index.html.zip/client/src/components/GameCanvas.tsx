import { useEffect, useRef, type ReactNode } from "react";
import { Engine } from "@babylonjs/core/Engines/engine";
import { Scene } from "@babylonjs/core/scene";
import { FreeCamera } from "@babylonjs/core/Cameras/freeCamera";
import { Vector3 } from "@babylonjs/core/Maths/math.vector";
import { Color3, Color4 } from "@babylonjs/core/Maths/math.color";
import { MeshBuilder } from "@babylonjs/core/Meshes/meshBuilder";
import { StandardMaterial } from "@babylonjs/core/Materials/standardMaterial";

const floatingLetters = [
  ["b", -4.9, 2.7, 0.18], ["ç", 4.6, 2.4, 0.22], ["ö", -5.2, -2.2, 0.2],
  ["ş", 5, -2.4, 0.16], ["ü", -3.8, 3.9, 0.12], ["ğ", 3.8, 3.6, 0.14],
  ["e", -5.7, 0.6, 0.12], ["u", 5.7, 0.8, 0.13], ["c", -3.2, -3.7, 0.14],
  ["h", 3.2, -3.8, 0.12],
] as const;

export function GameCanvas({ children }: { children: ReactNode }) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const engine = new Engine(canvas, true, { preserveDrawingBuffer: true, stencil: true });
    const scene = new Scene(engine);
    scene.clearColor = new Color4(0.976, 0.953, 0.902, 1);
    const camera = new FreeCamera("memory-camera", new Vector3(0, 0, -10), scene);
    camera.setTarget(Vector3.Zero());
    camera.minZ = 0.1;

    const nodes = floatingLetters.map(([letter, x, y, speed], index) => {
      const tile = MeshBuilder.CreatePlane(`letter-tile-${index}`, { size: 0.72 }, scene);
      tile.position = new Vector3(x, y, 1);
      tile.rotation.z = index % 2 ? 0.08 : -0.08;
      const material = new StandardMaterial(`letter-material-${index}`, scene);
      const colors = ["#8ED8E3", "#FFB84D", "#F58B7B", "#A8D5BA"];
      material.diffuseColor = Color3.FromHexString(colors[index % colors.length]);
      material.alpha = 0.17;
      tile.material = material;
      return { tile, speed, baseY: y, phase: index * 0.8 };
    });

    const observer = scene.onBeforeRenderObservable.add(() => {
      const t = performance.now() / 1000;
      nodes.forEach(node => {
        node.tile.position.y = node.baseY + Math.sin(t * node.speed + node.phase) * 0.08;
      });
    });

    engine.runRenderLoop(() => scene.render());
    const onResize = () => engine.resize();
    window.addEventListener("resize", onResize);

    return () => {
      scene.onBeforeRenderObservable.remove(observer);
      window.removeEventListener("resize", onResize);
      scene.dispose();
      engine.dispose();
    };
  }, []);

  return (
    <div className="game-canvas-shell">
      <canvas ref={canvasRef} className="game-canvas" aria-hidden="true" />
      <div className="game-content-layer">{children}</div>
    </div>
  );
}
