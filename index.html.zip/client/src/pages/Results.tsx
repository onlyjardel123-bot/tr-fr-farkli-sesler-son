import { useState } from "react";
import { Link } from "wouter";
import { ArrowLeft, LockKeyhole, Users, Clock3, Target } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { trpc } from "@/lib/trpc";
import { GameCanvas } from "@/components/GameCanvas";
import { localDateKey } from "@shared/gameData";

type DateFilter = "all" | "today";

export default function Results() {
  const { user, loading } = useAuth();
  const isAdmin = user?.role === "admin";
  const completions = trpc.game.listCompletions.useQuery(undefined, { enabled: isAdmin, retry: false });
  const [dateFilter, setDateFilter] = useState<DateFilter>("all");

  if (loading) {
    return <div className="results-loading">Sonuçlar yükleniyor…</div>;
  }

  if (!user) {
    return <div className="results-gate"><LockKeyhole size={34} /><h1>Öğretmen alanı</h1><p>Oyunu bitiren takma adlarını görmek için öğretmen olarak giriş yap.</p><button className="primary-button" onClick={() => startLogin()}>Giriş yap / Se connecter</button><Link href="/" className="back-link"><ArrowLeft size={16} /> Oyuna dön</Link></div>;
  }

  if (!isAdmin) {
    return <div className="results-gate"><LockKeyhole size={34} /><h1>Bu alan kilitli</h1><p>Sonuçları yalnızca oyunun sahibi görebilir.</p><Link href="/" className="back-link"><ArrowLeft size={16} /> Oyuna dön</Link></div>;
  }

  const allRows = completions.data ?? [];
  const today = localDateKey(Date.now());
  const rows = dateFilter === "today" ? allRows.filter(row => localDateKey(row.completedAt) === today) : allRows;

  return <GameCanvas><main className="results-page"><header className="results-header"><div><span className="eyebrow"><Users size={16} /> Öğretmen alanı</span><h1>Bitiren Kaşifler</h1><p>Çocukların ad-soyad bilgilerini ve oyun sonuçlarını burada görebilirsin.</p></div><Link href="/" className="back-link"><ArrowLeft size={16} /> Oyuna dön</Link></header><div className="results-toolbar"><label htmlFor="date-filter">Tarih filtresi</label><select id="date-filter" value={dateFilter} onChange={event => setDateFilter(event.target.value as DateFilter)}><option value="all">Tüm günler</option><option value="today">Sadece bugün</option></select>{dateFilter === "today" && <span>Bugün bitirenler gösteriliyor.</span>}</div><section className="results-summary"><div><Users size={20} /><b>{rows.length}</b><span>{dateFilter === "today" ? "bugünkü tamamlanma" : "tamamlanma"}</span></div><div><Target size={20} /><b>28</b><span>kartlık oyun</span></div><div><Clock3 size={20} /><b>MANTI</b><span>okul şifresi</span></div></section><section className="results-table-wrap"><table><thead><tr><th>Ad Soyad</th><th>Hamle</th><th>Yanlış</th><th>Süre</th><th>Tamamlandı</th></tr></thead><tbody>{rows.length === 0 ? <tr><td colSpan={5} className="empty-results">{dateFilter === "today" ? "Bugün henüz bitiren yok." : "Henüz bitiren yok. İlk kaşif yolda!"}</td></tr> : rows.map(row => <tr key={row.id}><td><strong>{row.nickname}</strong></td><td>{row.moves}</td><td>{row.mistakes}</td><td>{Math.floor(row.durationSeconds / 60)} dk {row.durationSeconds % 60} sn</td><td>{new Date(row.completedAt).toLocaleString("tr-TR")}</td></tr>)}</tbody></table></section></main></GameCanvas>;
}
