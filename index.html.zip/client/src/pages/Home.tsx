import { useEffect, useMemo, useState } from "react";
import { Link } from "wouter";
import { Volume2, VolumeX, Sparkles, RotateCcw, Trophy, ArrowRight, LockKeyhole } from "lucide-react";
import { GameCanvas } from "@/components/GameCanvas";
import { trpc } from "@/lib/trpc";
import { buildDeck, FINAL_PASSWORD, normalizeNickname, PAIRS, type GameCard } from "@shared/gameData";

const PAPER_BACKGROUND = "/manus-storage/turkce-harf-hafiza-paper_24fdd55e.png";
const TURTLE = "/manus-storage/turkce-harf-hafiza-turtle_4c4d42c3.png";

function speak(text: string, enabled: boolean) {
  if (!enabled || typeof window === "undefined" || !("speechSynthesis" in window)) return;
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = "tr-TR";
  utterance.rate = 0.82;
  utterance.pitch = 1.1;
  window.speechSynthesis.speak(utterance);
}

function playMatchSounds(enabled: boolean) {
  if (!enabled || typeof window === "undefined") return;
  const audioWindow = window as typeof window & { webkitAudioContext?: typeof AudioContext };
  const AudioContextConstructor = window.AudioContext ?? audioWindow.webkitAudioContext;
  if (!AudioContextConstructor) return;
  const context = new AudioContextConstructor();
  void context.resume();
  const master = context.createGain();
  master.gain.setValueAtTime(0.16, context.currentTime);
  master.connect(context.destination);

  const clapBuffer = context.createBuffer(1, Math.floor(context.sampleRate * 0.12), context.sampleRate);
  const clapData = clapBuffer.getChannelData(0);
  for (let index = 0; index < clapData.length; index += 1) {
    clapData[index] = (Math.random() * 2 - 1) * Math.pow(1 - index / clapData.length, 2.4);
  }
  [0, 0.06, 0.12, 0.18].forEach(offset => {
    const clap = context.createBufferSource();
    const filter = context.createBiquadFilter();
    const gain = context.createGain();
    clap.buffer = clapBuffer;
    filter.type = "bandpass";
    filter.frequency.value = 1500 + Math.random() * 900;
    filter.Q.value = 0.7;
    gain.gain.value = 0.9;
    clap.connect(filter).connect(gain).connect(master);
    clap.start(context.currentTime + offset);
    clap.stop(context.currentTime + offset + 0.12);
  });

  const whistle = context.createOscillator();
  const whistleGain = context.createGain();
  whistle.type = "sine";
  whistle.frequency.setValueAtTime(420, context.currentTime + 0.16);
  whistle.frequency.exponentialRampToValueAtTime(1250, context.currentTime + 0.48);
  whistleGain.gain.setValueAtTime(0.001, context.currentTime + 0.16);
  whistleGain.gain.exponentialRampToValueAtTime(0.24, context.currentTime + 0.32);
  whistleGain.gain.exponentialRampToValueAtTime(0.001, context.currentTime + 0.52);
  whistle.connect(whistleGain).connect(master);
  whistle.start(context.currentTime + 0.16);
  whistle.stop(context.currentTime + 0.54);

  const crackle = context.createBufferSource();
  const crackleGain = context.createGain();
  crackle.buffer = context.createBuffer(1, Math.floor(context.sampleRate * 0.22), context.sampleRate);
  const crackleData = crackle.buffer.getChannelData(0);
  for (let index = 0; index < crackleData.length; index += 1) {
    crackleData[index] = Math.random() > 0.86 ? (Math.random() * 2 - 1) : 0;
  }
  crackleGain.gain.setValueAtTime(0.45, context.currentTime + 0.48);
  crackleGain.gain.exponentialRampToValueAtTime(0.001, context.currentTime + 0.8);
  crackle.connect(crackleGain).connect(master);
  crackle.start(context.currentTime + 0.48);
  crackle.stop(context.currentTime + 0.82);
  window.setTimeout(() => void context.close(), 1100);
}

function cardSpeech(card: GameCard) {
  return card.type === "letter" ? card.letter : card.word;
}

export default function Home() {
  const [nickname, setNickname] = useState("");
  const [started, setStarted] = useState(false);
  const [deck, setDeck] = useState<GameCard[]>(() => buildDeck());
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [matchedIds, setMatchedIds] = useState<string[]>([]);
  const [moves, setMoves] = useState(0);
  const [mistakes, setMistakes] = useState(0);
  const [startedAt, setStartedAt] = useState<number | null>(null);
  const [audioEnabled, setAudioEnabled] = useState(true);
  const [completionSaved, setCompletionSaved] = useState(false);
  const [burstId, setBurstId] = useState(0);
  const saveCompletion = trpc.game.saveCompletion.useMutation();
  const finished = started && matchedIds.length === PAIRS.length;
  const progress = Math.round((matchedIds.length / PAIRS.length) * 100);

  useEffect(() => {
    if (!finished || !startedAt || completionSaved) return;
    setCompletionSaved(true);
    saveCompletion.mutate({
      nickname: normalizeNickname(nickname),
      moves,
      mistakes,
      durationSeconds: Math.max(0, Math.round((Date.now() - startedAt) / 1000)),
    });
  }, [audioEnabled, completionSaved, finished, mistakes, moves, nickname, saveCompletion, startedAt]);

  const matchedPairSet = useMemo(() => new Set(matchedIds), [matchedIds]);

  function startGame() {
    const cleanName = normalizeNickname(nickname);
    if (!cleanName) return;
    setNickname(cleanName);
    setDeck(buildDeck());
    setSelectedIds([]);
    setMatchedIds([]);
    setMoves(0);
    setMistakes(0);
    setCompletionSaved(false);
    setStartedAt(Date.now());
    setStarted(true);
  }

  function restartGame() {
    setStarted(false);
    setStartedAt(null);
    setSelectedIds([]);
    setMatchedIds([]);
    setMoves(0);
    setMistakes(0);
    setCompletionSaved(false);
    setDeck(buildDeck());
  }

  function handleCardClick(card: GameCard) {
    if (!started || selectedIds.length >= 2 || selectedIds.includes(card.id) || matchedPairSet.has(card.pairId)) return;
    speak(cardSpeech(card), audioEnabled);
    const nextSelected = [...selectedIds, card.id];
    setSelectedIds(nextSelected);
    if (nextSelected.length < 2) return;

    setMoves(value => value + 1);
    const first = deck.find(item => item.id === nextSelected[0]);
    if (!first) return;
    if (first.pairId === card.pairId && first.type !== card.type) {
      playMatchSounds(audioEnabled);
      window.setTimeout(() => {
        setMatchedIds(value => [...value, card.pairId]);
        setSelectedIds([]);
        setBurstId(value => value + 1);
      }, 520);
    } else {
      setMistakes(value => value + 1);
      window.setTimeout(() => {
        setSelectedIds([]);
      }, 820);
    }
  }

  if (!started) {
    return (
      <GameCanvas>
        <main className="page-frame intro-frame">
          <header className="topbar">
            <div className="brand-lockup"><span className="brand-dot">A</span><div><strong>Harf Kaşifleri</strong><span>Türkçe öğren, kartları eşleştir!</span></div></div>
            <Link href="/sonuclar" className="teacher-link"><LockKeyhole size={15} /> Öğretmen sonuçları</Link>
          </header>
          <section className="intro-card" style={{ backgroundImage: `url(${PAPER_BACKGROUND})` }}>
            <div className="intro-copy">
              <div className="eyebrow"><Sparkles size={16} /> Mini dil macerası</div>
              <h1>Türkçe Harf<br /><em>Hafıza Oyunu</em></h1>
              <p className="lead">Harfleri bul, kelimeleri öğren, hafızanı parlat!</p>
              <div className="bilingual-instructions">
                <div><span className="language-chip tr-chip">TÜRKÇE</span><p>Her harf için <b>bir resim</b> var. Harf kartını ve o harfle başlayan resimli kelime kartını bul!</p></div>
                <div><span className="language-chip fr-chip">FRANÇAIS</span><p>Pour chaque lettre, il y a <b>une image</b>. Trouve la carte de la lettre et l'image du mot !</p></div>
              </div>
              <div className="special-note"><span>Ğ</span><div><b>Minik not / Petite note</b><p>Ğ kelimenin başında olmaz: <b>dağ</b>, <b>yağmur</b> gibi kelimelerin içinde görürüz.</p><p>Aucun mot turc ne commence par la lettre Ğ.</p></div></div>
              <div className="name-form"><label htmlFor="nickname">Adın ve soyadın / Ton prénom et ton nom</label><div className="name-row"><input id="nickname" value={nickname} onChange={event => setNickname(event.target.value.slice(0, 80))} onKeyDown={event => event.key === "Enter" && startGame()} placeholder="Örn. Ayşe Yılmaz" maxLength={80} /><button onClick={startGame} disabled={!normalizeNickname(nickname)} className="primary-button">Oyuna başla <ArrowRight size={19} /></button></div><small>Oyunu takip edebilmemiz için adını ve soyadını yaz.</small></div>
            </div>
            <div className="intro-art"><div className="sunburst">28<br /><small>KART</small></div><img src={TURTLE} alt="Elinde harf kartı tutan sevimli kaplumbağa" /><div className="speech-bubble">Hazır mısın?<br /><small>Prêt·e ?</small></div></div>
          </section>
          <footer className="intro-footer"><span>🔊 Kartlara tıklayınca Türkçe okur.</span><span>14 harf · 14 kelime çifti</span><span>Ses aç/kapa oyunda</span></footer>
        </main>
      </GameCanvas>
    );
  }

  if (finished) {
    return (
      <GameCanvas>
        <main className="page-frame completion-frame">
          <div className="completion-card">
            <div className="confetti-line">✦ ✧ ✦ ✧ ✦</div>
            <img className="completion-turtle" src={TURTLE} alt="Tebrikler kaplumbağası" />
            <div className="eyebrow"><Trophy size={17} /> Harika iş çıkardın!</div>
            <h1>Tebrikler, {nickname}!</h1>
            <p className="lead">Bütün kart çiftlerini buldun.</p>
            <div className="completion-stats"><span><b>{moves}</b> hamle<br /><small>coups</small></span><span><b>{mistakes}</b> yanlış<br /><small>erreurs</small></span><span><b>14</b> çift<br /><small>paires</small></span></div>
            <div className="password-box"><span>OKUL ŞİFRESİ / MOT DE PASSE</span><strong>{FINAL_PASSWORD}</strong><p>Oyunun sonunda Türk yemeğinin adını buldun! Bu, Türk kültürüne ait bir yemektir. Şifreyi okulda öğretmenine söyle ve bir köpek yapıştırması kazan!<br />À la fin, tu as trouvé le nom d'un plat turc ! Dis-le à ton enseignant à l'école et gagne un autocollant de chien !</p></div>
            <button className="primary-button center-button" onClick={restartGame}><RotateCcw size={18} /> Yeniden oyna / Rejouer</button>
          </div>
        </main>
      </GameCanvas>
    );
  }

  return (
    <GameCanvas>
      <main className="page-frame game-frame">
        <header className="game-topbar">
          <div className="brand-lockup"><span className="brand-dot">A</span><div><strong>Harf Kaşifleri</strong><span>Selam {nickname}!</span></div></div>
          <div className="game-actions"><button className="icon-button" onClick={() => setAudioEnabled(value => !value)} aria-label={audioEnabled ? "Sesi kapat" : "Sesi aç"}>{audioEnabled ? <Volume2 size={19} /> : <VolumeX size={19} />}</button><button className="restart-button" onClick={restartGame}><RotateCcw size={16} /> Baştan</button></div>
        </header>
        <section className="game-instructions"><div><span className="language-chip tr-chip">ŞİMDİ OYUN ZAMANI!</span><p>Harf kartını ve onunla başlayan kelime resmini bul.</p></div><div><span className="language-chip fr-chip">À TOI DE JOUER !</span><p>Associe la lettre avec l'image du mot.</p></div><div className="progress-area"><div className="progress-label"><span>{matchedIds.length} / 14 çift</span><span>{progress}%</span></div><div className="progress-track"><div style={{ width: `${progress}%` }} /></div></div></section>
        <section className="stat-row"><span><b>{moves}</b> hamle / coups</span><span><b>{mistakes}</b> yanlış / erreurs</span><span><b>{PAIRS.length}</b> harf çifti / paires</span></section>
        {burstId > 0 && <div key={burstId} className="balloon-pop" aria-hidden="true"><span className="pop-balloon balloon-one" /><span className="pop-balloon balloon-two" /><span className="pop-balloon balloon-three" /><span className="pop-balloon balloon-four" /><span className="pop-balloon balloon-five" /><span className="firework firework-a">✹</span><span className="firework firework-b">✦</span><span className="firework firework-c">✹</span><span className="firework firework-d">✦</span><b>POP!</b><i>✦</i><em>✦</em></div>}
        <div className="memory-grid" aria-label="Hafıza kartları">
          {deck.map(card => {
            const isFaceUp = selectedIds.includes(card.id) || matchedPairSet.has(card.pairId);
            return <button key={card.id} className={`memory-card ${isFaceUp ? "is-flipped" : ""} ${matchedPairSet.has(card.pairId) ? "is-matched" : ""}`} onClick={() => handleCardClick(card)} aria-label={isFaceUp ? cardSpeech(card) : "Kapalı hafıza kartı"}>
              <span className="card-inner"><span className="card-back"><span>?</span><small>Harf<br />Kaşifi</small></span><span className="card-front">{card.type === "letter" ? <strong className="letter-face">{card.letter.toLocaleUpperCase("tr-TR")}</strong> : <><span className="emoji-face">{card.emoji}</span><strong>{card.word}</strong><small>{card.french}</small></>}</span></span>
            </button>;
          })}
        </div>
        <p className="game-tip">💡 İpucu / Astuce: Kartın Türkçe sesini duymak için karta dokun!</p>
      </main>
    </GameCanvas>
  );
}
