import { COOKIE_NAME } from "@shared/const";
import { FINAL_PASSWORD, normalizeNickname } from "@shared/gameData";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, publicProcedure, router } from "./_core/trpc";
import { createGameCompletion, listGameCompletions } from "./db";
import { z } from "zod";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  game: router({
    saveCompletion: publicProcedure
      .input(z.object({
        nickname: z.string().min(1).max(80),
        moves: z.number().int().min(1).max(1000),
        mistakes: z.number().int().min(0).max(1000),
        durationSeconds: z.number().int().min(0).max(86400),
      }))
      .mutation(async ({ input }) => {
        const nickname = normalizeNickname(input.nickname);
        if (nickname.length < 1) throw new Error("Ad ve soyad gerekli");
        await createGameCompletion({
          nickname,
          moves: input.moves,
          mistakes: input.mistakes,
          durationSeconds: input.durationSeconds,
          password: FINAL_PASSWORD,
        });
        return { saved: true } as const;
      }),
    listCompletions: adminProcedure.query(async () => listGameCompletions()),
  }),
});

export type AppRouter = typeof appRouter;
