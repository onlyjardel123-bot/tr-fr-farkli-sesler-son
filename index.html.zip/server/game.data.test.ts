import { describe, expect, it } from "vitest";
import { buildDeck, FINAL_PASSWORD, localDateKey, normalizeNickname, PAIRS, TARGET_LETTERS } from "@shared/gameData";

describe("Türkçe harf hafıza oyunu veri seti", () => {
  it("14 hedef harfi ve her harf için tek kelimeyi içerir", () => {
    expect(TARGET_LETTERS).toHaveLength(14);
    expect(PAIRS).toHaveLength(14);
    for (const letter of TARGET_LETTERS) {
      expect(PAIRS.filter(pair => pair.letter === letter)).toHaveLength(1);
    }
  });

  it("her kelime için bir harf kartı ve bir resim kartı üretir", () => {
    const deck = buildDeck();
    expect(deck).toHaveLength(28);
    expect(new Set(deck.map(card => card.pairId)).size).toBe(14);
    for (const pair of PAIRS) {
      const cards = deck.filter(card => card.pairId === pair.id);
      expect(cards.map(card => card.type).sort()).toEqual(["letter", "word"]);
    }
  });

  it("tamamlanma tarihini yerel gün anahtarına çevirir", () => {
    const value = new Date(2026, 8, 21, 14, 30, 0);
    expect(localDateKey(value)).toBe("2026-09-21");
  });

  it("ad ve soyadı 80 karaktere kadar temizler", () => {
    expect(normalizeNickname("  Ayşe   Yılmaz  ")).toBe("Ayşe Yılmaz");
    expect(normalizeNickname("a".repeat(100))).toHaveLength(80);
  });

  it("Türk kültürüne ait yemek şifresini kullanır", () => {
    expect(FINAL_PASSWORD).toBe("MANTI");
  });
});
