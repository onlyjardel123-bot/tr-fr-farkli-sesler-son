# Memory

- Project initialized as `web-db-user` because the owner wants to know which nicknames finished the game.
- No real identity is requested from children. Public completion mutation accepts only a bounded nickname and game statistics.
- The final school password is intentionally fixed as `MANTI`, a Turkish cultural dish, and is revealed on the completion screen with a reminder to say it at school to earn a sticker.
- The intro teaches that each letter has one image; the French Ğ hint is “Aucun mot turc ne commence par la lettre Ğ.” The completion message asks children to tell the Turkish food password to their teacher at school to earn a dog sticker.
- The letter `ğ` needs an explicit note: it does not begin native Turkish words; the examples use `dağ` and `yağmur` to teach the sound/letter in context.
- Browser speech is unlocked by user interaction and uses `tr-TR` voice settings. Speech can be toggled off.
- Each requested letter now has exactly one concept, with `yıldız` added for `y`; the deck is 28 cards total.
- Speech says only the visible Turkish token: a letter card says `ç`, and a word card says `çilek`. It does not say labels, French translations, greetings or praise.
- A correct match triggers a visual balloon-pop burst without extra spoken feedback.
- Students now enter their full name and surname; the displayed field and teacher table use “Ad Soyad”, while the existing database column remains `nickname` internally for compatibility.
- Babylon.js is used for a lifecycle-safe decorative canvas layer, while the accessible cards remain regular HTML buttons for keyboard and screen-reader support.
