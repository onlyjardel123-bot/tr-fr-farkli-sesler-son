# Game Plan: Türkçe Harf Hafıza Oyunu

## Risk Tasks

### 1. Sesli etkileşim ve kart eşleştirme
- **Why isolated:** Tarayıcı sesleri ilk kullanıcı tıklamasından önce otomatik başlayamaz; ayrıca harf kartı ile resimli kelime kartının eşleşmesi, yanlış kartların kapanması ve yeniden başlama akışı aynı anda güvenilir çalışmalıdır.
- **Approach:** SpeechSynthesis API yalnızca tıklama ve oyun başlatma gibi kullanıcı eylemlerinden sonra çağrılacak. Oyun verisi tek bir paylaşılan sabit diziden üretilecek; her çiftte aynı `pairId` bulunacak. İki kart açıldıktan sonra eşleşme kısa bir gecikmeyle kontrol edilecek, yanlışlar kapanacak, doğrular sabit kalacak.
- **Verify:** Harf kartına tıklayınca yalnızca harf Türkçe okunur; resimli karta tıklayınca yalnızca kelime okunur; doğru eşleşmede balon patlar; yanlış eşleşme kapanır; tüm 14 çift bitince sonuç ekranı açılır.

## Main Build

7-8 yaş çocuklara uygun, Türkçe açıklaması üstte ve Fransızca açıklaması hemen altında olan, öğrencinin ad-soyadıyla başlayan 28 kartlık sesli bir hafıza oyunu yapılacak. 14 hedef harfin (b, c, ç, e, g, ğ, h, ı, ö, s, ş, u, ü, y) her biri için tek basit kavram bulunacak. Her eşleşme bir büyük harf kartı ve kavramın resmi, Türkçe adı ve küçük Fransızca karşılığı bulunan karttan oluşacak. Ğ için başta kullanım kuralı doğru biçimde anlatılacak: “Ğ kelimenin başında olmaz; dağ gibi kelimelerin içinde görülür.”

- **Assets needed:** Neşeli eğitim arayüzü görsel hedefi, yumuşak kâğıt/confetti arka planı ve küçük kaplumbağa maskotu. Kartların resimleri basit, büyük emoji/piktogramlarla erişilebilir biçimde üretilecek.
- **Verify:**
  - Oyun Türkçe açıklamayı önce, Fransızca açıklamayı sonra gösterir.
  - Başlamadan önce sadece takma ad istenir; çocuk oyuna girer.
  - 28 kart görünür, kartlar tıklanabilir ve mobil ekranda taşmadan akışa uyum sağlar.
  - Harf, kelime, Fransızca karşılık, ilerleme, hamle ve yanlış sayısı okunaklıdır.
  - Ses aç/kapa kontrolü çalışır; `prefers-reduced-motion` için gereksiz hareketler azalır.
  - Doğru eşleşmeler kalır, yanlış eşleşmeler kapanır, yeniden başlatma temiz bir deste kurar.
  - Her harf için bir resim olduğu açıklanır; Fransızca Ğ ipucu “Aucun mot turc ne commence par la lettre Ğ.” şeklindedir. Tamamlanınca MANTI görünür; bunun Türk kültürüne ait bir yemek olduğu, çocuğun şifreyi okulda öğretmenine söylemesi ve köpek yapıştırması kazanacağı belirtilir.
  - Tamamlanma, yalnızca takma ad ve oyun istatistikleriyle veritabanına kaydedilir; yönetici sonuç ekranı giriş ister.
  - No browser console errors during capture.
  - Generated art direction, palette, mascot and background are visible in the running game.
  - **Presentation proof bundle:** WebDev screenshot captures of start, active game and completion states.

## Privacy note

The public game records only the nickname entered by the player, completion time and gameplay statistics. It does not ask for a real name, email, school, location or login. The `/sonuclar` page is restricted to the project owner/admin session.
